This directory contains all prototypic schematics for the Enamel project.

# braille-research


Treasure Box Braille (TBB) research




# lasercut directory


Ver = version


Var = variant



Ver1VarA: cardboard external case


Ver1VarB: foamboard external case


Ver1VarC: mdf external case



# braille-cheatsheet



test directory: 
various tested models to determine ideal pin height and shape

